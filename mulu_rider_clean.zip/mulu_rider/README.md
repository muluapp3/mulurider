MULU Rider App - Flutter starter
--------------------------------
How to run:
1. Install Flutter SDK.
2. Copy this project to your machine.
3. Run `flutter pub get` and then `flutter run`.

Notes:
- This project uses mock services for incoming requests and location.
- To integrate real services, replace services/mock_server.dart and services/location_service.dart
