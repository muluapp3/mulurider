import 'package:flutter/material.dart';
import '../models/ride_request.dart';
import 'active_ride.dart';

class RideRequestView extends StatelessWidget {
  final RideRequest request;
  const RideRequestView({super.key, required this.request});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ride Request')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Pickup: \${request.pickup}', style: const TextStyle(fontSize: 18)),
            Text('Drop: \${request.drop}', style: const TextStyle(fontSize: 18)),
            Text('Distance: \${request.distanceKm} km', style: const TextStyle(fontSize: 16)),
            Text('Fare: ₹\${request.fare}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 30),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      // Accept -> navigate to active ride
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ActiveRide(request: request)));
                    },
                    child: const Text('ACCEPT'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('REJECT'),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
