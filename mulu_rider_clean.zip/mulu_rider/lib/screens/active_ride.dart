import 'package:flutter/material.dart';
import '../models/ride_request.dart';
import '../services/location_service.dart';

class ActiveRide extends StatefulWidget {
  final RideRequest request;
  const ActiveRide({super.key, required this.request});

  @override
  State<ActiveRide> createState() => _ActiveRideState();
}

class _ActiveRideState extends State<ActiveRide> {
  final MockLocationService _location = MockLocationService();
  Map<String, double>? _lastLoc;

  @override
  void initState() {
    super.initState();
    _location.start();
    _location.onLocation.listen((loc) {
      setState(() => _lastLoc = loc);
    });
  }

  @override
  void dispose() {
    _location.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Active Ride')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('\${widget.request.pickup} → \${widget.request.drop}', style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 12),
            Text('Fare: ₹\${widget.request.fare} • \${widget.request.distanceKm} km'),
            const SizedBox(height: 24),
            if (_lastLoc == null) const CircularProgressIndicator() else Column(
              children: [
                Text('Current: lat: \${_lastLoc!['lat']!.toStringAsFixed(5)}, lng: \${_lastLoc!['lng']!.toStringAsFixed(5)}'),
                const SizedBox(height: 12),
                const Text('Live route map placeholder (integrate Google Maps)')
              ],
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                // Complete ride
                showDialog(context: context, builder: (_) => AlertDialog(
                  title: const Text('Complete Ride'),
                  content: const Text('Mark ride as completed?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.popUntil(context, ModalRoute.withName('/main')), child: const Text('Yes')),
                  ],
                ));
              },
              child: const Text('Complete Ride'),
            )
          ],
        ),
      ),
    );
  }
}
