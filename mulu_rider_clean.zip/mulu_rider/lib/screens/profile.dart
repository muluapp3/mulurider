import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  const Profile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Rider Name', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Phone: +91 9XXXXXXXXX'),
            const SizedBox(height: 16),
            const Text('Vehicle: Bike • KA-01-AB-1234'),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: () {}, child: const Text('Edit Profile')),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: () {}, child: const Text('Logout')),
          ],
        ),
      ),
    );
  }
}
