import 'package:flutter/material.dart';

class Earnings extends StatelessWidget {
  const Earnings({super.key});

  @override
  Widget build(BuildContext context) {
    // Mock earnings data
    final total = 12450;
    final today = 780;

    return Scaffold(
      appBar: AppBar(title: const Text('Earnings')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Total Earnings: ₹$total', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('Today: ₹$today'),
            const SizedBox(height: 20),
            const Text('Trips', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: 8,
                itemBuilder: (context, i) => ListTile(
                  title: Text('Trip #\${i+1}'),
                  subtitle: const Text('₹120 • 4.2 km'),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
