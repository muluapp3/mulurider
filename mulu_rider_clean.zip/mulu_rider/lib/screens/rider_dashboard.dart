import 'package:flutter/material.dart';
import '../services/mock_server.dart';
import '../models/ride_request.dart';
import 'ride_request_view.dart';

class RiderDashboard extends StatefulWidget {
  const RiderDashboard({super.key});

  @override
  State<RiderDashboard> createState() => _RiderDashboardState();
}

class _RiderDashboardState extends State<RiderDashboard> {
  final MockServer _server = MockServer();
  final List<RideRequest> _requests = [];
  late final Stream<RideRequest> _stream;

  @override
  void initState() {
    super.initState();
    _server.start();
    _stream = _server.onRequest;
    _stream.listen((r) {
      setState(() => _requests.insert(0, r));
      // optionally show a local notification here
    });
  }

  @override
  void dispose() {
    _server.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rider Dashboard')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text('Incoming Requests', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Expanded(
              child: _requests.isEmpty
                  ? const Center(child: Text('No incoming requests yet.'))
                  : ListView.builder(
                      itemCount: _requests.length,
                      itemBuilder: (context, index) {
                        final r = _requests[index];
                        return Card(
                          color: Colors.grey[900],
                          child: ListTile(
                            title: Text('\${r.pickup} → \${r.drop}'),
                            subtitle: Text('Fare: ₹\${r.fare} • \${r.distanceKm} km • \${r.intercity ? 'Intercity' : 'Local'}'),
                            trailing: ElevatedButton(
                              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RideRequestView(request: r))),
                              child: const Text('View'),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
