import 'package:flutter/material.dart';
import 'rider_dashboard.dart';
import 'rider_online_offline.dart';
import 'earnings.dart';
import 'profile.dart';

class RiderMain extends StatefulWidget {
  const RiderMain({super.key});

  @override
  State<RiderMain> createState() => _RiderMainState();
}

class _RiderMainState extends State<RiderMain> {
  int _index = 0;
  final _pages = [
    const RiderDashboard(),
    const RiderOnlineOffline(),
    const Earnings(),
    const Profile(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'Dashboard'),
          BottomNavigationBarItem(icon: Icon(Icons.toggle_on), label: 'Availability'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet), label: 'Earnings'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
