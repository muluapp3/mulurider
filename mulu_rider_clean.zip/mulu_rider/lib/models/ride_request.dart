class RideRequest {
  final String id;
  final String pickup;
  final String drop;
  final int fare;
  final double distanceKm;
  final bool intercity;

  RideRequest({
    required this.id,
    required this.pickup,
    required this.drop,
    required this.fare,
    required this.distanceKm,
    this.intercity = false,
  });
}
