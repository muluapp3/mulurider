import 'package:flutter/material.dart';
import 'screens/rider_login.dart';
import 'screens/rider_main.dart';

class MuluRiderApp extends StatelessWidget {
  const MuluRiderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MULU Rider',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        colorScheme: ColorScheme.dark(primary: Colors.black),
        scaffoldBackgroundColor: Colors.black,
        appBarTheme: const AppBarTheme(backgroundColor: Colors.black87),
      ),
      initialRoute: '/',
      routes: {
        '/': (_) => const RiderLogin(),
        '/main': (_) => const RiderMain(),
      },
    );
  }
}
