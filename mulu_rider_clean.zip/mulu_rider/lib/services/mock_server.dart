import 'dart:async';
import '../models/ride_request.dart';

/// Mock server that emits ride requests every 20-40 seconds.
class MockServer {
  final _controller = StreamController<RideRequest>.broadcast();
  Stream<RideRequest> get onRequest => _controller.stream;
  Timer? _timer;
  int _counter = 0;

  void start() {
    _scheduleNext();
  }

  void stop() {
    _timer?.cancel();
  }

  void _scheduleNext() {
    final delay = 20 + (_counter % 20); // 20..39s
    _timer = Timer(Duration(seconds: delay), () {
      final req = RideRequest(
        id: 'REQ_\${DateTime.now().millisecondsSinceEpoch}',
        pickup: _samplePickup(),
        drop: _sampleDrop(),
        fare: 40 + (_counter * 5) % 200,
        distanceKm: (3 + (_counter % 12)).toDouble(),
        intercity: (_counter % 7) == 0, // some intercity
      );
      _controller.add(req);
      _counter++;
      _scheduleNext();
    });
  }

  String _samplePickup() {
    final list = ['Vijay Nagar', 'Palasia', 'MG Road', 'Indore Bus Stand', 'Rajwada'];
    return list[_counter % list.length];
  }

  String _sampleDrop() {
    final list = ['Palasia', 'Vijay Nagar', 'Pipliyahana', 'Bhanwarkuan', 'Annapurna'];
    return list[_counter % list.length];
  }
}
