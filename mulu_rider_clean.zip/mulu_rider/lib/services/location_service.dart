import 'dart:async';

/// Mock location service - emits a moving lat/lng every 2s while active.
class MockLocationService {
  final _controller = StreamController<Map<String, double>>.broadcast();
  Stream<Map<String, double>> get onLocation => _controller.stream;
  Timer? _timer;
  double _lat = 22.7196; // Indore lat
  double _lng = 75.8577; // Indore lng

  void start() {
    _timer = Timer.periodic(const Duration(seconds: 2), (_) {
      // move slightly
      _lat += (0.0002 - 0.0004 * (DateTime.now().second % 2));
      _lng += (0.0002 - 0.0004 * (DateTime.now().second % 3));
      _controller.add({'lat': _lat, 'lng': _lng});
    });
  }

  void stop() {
    _timer?.cancel();
  }

  void dispose() {
    _timer?.cancel();
    _controller.close();
  }
}
